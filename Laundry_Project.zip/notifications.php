<?php
require_once 'config/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Mark all as read if requested
if (isset($_POST['mark_read'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([$userId]);
}

// Fetch notifications
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="max-w-4xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-extrabold text-gray-900">Notifications</h1>
            <p class="mt-2 text-gray-600">Real-time updates about your laundry orders.</p>
        </div>
        <?php if (!empty($notifications)): ?>
        <form method="POST">
            <button name="mark_read" class="text-sm font-bold text-primary hover:text-secondary flex items-center gap-2">
                <i class="fas fa-check-double"></i> Mark all as read
            </button>
        </form>
        <?php endif; ?>
    </div>

    <?php if (empty($notifications)): ?>
        <div class="bg-white rounded-2xl shadow-sm p-12 text-center border border-gray-100">
            <div class="mx-auto h-20 w-20 bg-gray-50 rounded-full flex items-center justify-center text-gray-300 mb-4">
                <i class="fas fa-bell-slash fa-2x"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-900 border-none">No notifications yet</h2>
            <p class="text-gray-500">We'll alert you here when your laundry status changes.</p>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <?php foreach ($notifications as $notif): ?>
            <div class="bg-white p-6 rounded-2xl border <?php echo $notif['is_read'] ? 'border-gray-100 opacity-75' : 'border-blue-100 bg-blue-50/30'; ?> shadow-sm flex gap-4 transition hover:shadow-md">
                <div class="h-12 w-12 rounded-xl <?php echo $notif['is_read'] ? 'bg-gray-100 text-gray-400' : 'bg-blue-100 text-blue-600'; ?> flex flex-shrink-0 items-center justify-center">
                    <i class="fas <?php echo $notif['type'] == 'status_update' ? 'fa-sync-alt' : 'fa-info-circle'; ?> fa-lg"></i>
                </div>
                <div class="flex-grow">
                    <div class="flex justify-between items-start">
                        <h3 class="font-bold text-gray-900"><?php echo htmlspecialchars($notif['title']); ?></h3>
                        <span class="text-[10px] font-bold text-gray-400 uppercase"><?php echo date('M d, H:i', strtotime($notif['created_at'])); ?></span>
                    </div>
                    <p class="text-gray-600 text-sm mt-1"><?php echo htmlspecialchars($notif['message']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
