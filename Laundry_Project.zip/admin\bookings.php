<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$statusFilter = $_GET['status'] ?? '';
$searchQuery = $_GET['search'] ?? '';

// Base Query
$sql = "SELECT b.*, u.name as user_name, u.email as user_email 
        FROM bookings b 
        JOIN users u ON b.user_id = u.id 
        WHERE 1=1";
$params = [];

if ($statusFilter) {
    $sql .= " AND b.status = ?";
    $params[] = $statusFilter;
}

if ($searchQuery) {
    $sql .= " AND (u.name LIKE ? OR u.email LIKE ? OR b.id LIKE ?)";
    $params[] = "%$searchQuery%";
    $params[] = "%$searchQuery%";
    $params[] = "%$searchQuery%";
}

$sql .= " ORDER BY b.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

// Map statuses to badge colors
$statusClasses = [
    'Pending' => 'bg-orange-100 text-orange-700 border-orange-200',
    'Received' => 'bg-blue-100 text-blue-700 border-blue-200',
    'Completed' => 'bg-green-100 text-green-700 border-green-200',
    'Cancelled' => 'bg-red-100 text-red-700 border-red-200'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Manage Bookings - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: { extend: { fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'] }, colors: { primary: '#3b82f6' } } }
        }
    </script>
</head>
<body class="bg-[#f8fafc] font-sans antialiased text-gray-800">
    <?php include 'includes/sidebar.php'; ?>

    <div class="ml-64 p-8 min-h-screen">
        <div class="flex justify-between items-end mb-8">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Manage Bookings</h1>
                <p class="text-gray-500 text-sm mt-1">Total Found: <?php echo count($bookings); ?> bookings</p>
            </div>
            
            <!-- Filters -->
            <form action="" method="GET" class="flex items-center gap-3">
                <div class="relative">
                    <i data-lucide="search" class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($searchQuery); ?>" placeholder="Search ID, Name..." class="pl-10 pr-4 py-2.5 bg-white border border-gray-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-100 transition shadow-sm w-64">
                </div>
                <select name="status" onchange="this.form.submit()" class="px-4 py-2.5 bg-white border border-gray-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-100 transition shadow-sm cursor-pointer">
                    <option value="">All Statuses</option>
                    <?php foreach ($statusClasses as $s => $c): ?>
                    <option value="<?php echo $s; ?>" <?php echo $statusFilter == $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <div class="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-50/50">
                    <tr>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Booking ID</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Customer</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Amount</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Payment</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php if (empty($bookings)): ?>
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-gray-400 italic">
                            <div class="flex flex-col items-center">
                                <i data-lucide="package-search" class="w-12 h-12 mb-3 opacity-20"></i>
                                No data found matching your filters.
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>

                    <?php foreach ($bookings as $booking): ?>
                    <tr class="hover:bg-gray-50/50 transition-colors">
                        <td class="px-6 py-5 font-bold text-gray-900 text-sm">#BK-<?php echo $booking['id']; ?></td>
                        <td class="px-6 py-5">
                            <div class="text-sm font-bold text-gray-900"><?php echo htmlspecialchars($booking['user_name']); ?></div>
                            <div class="text-xs text-gray-500"><?php echo htmlspecialchars($booking['user_email']); ?></div>
                        </td>
                        <td class="px-6 py-5 text-sm font-bold text-gray-900">₱<?php echo number_format($booking['total_amount'], 2); ?></td>
                        <td class="px-6 py-5 text-xs text-gray-500"><?php echo $booking['payment_method']; ?></td>
                        <td class="px-6 py-5">
                            <span class="px-3 py-1 rounded-full text-[10px] font-bold border <?php echo $statusClasses[$booking['status']] ?? 'bg-gray-100'; ?>">
                                <?php echo $booking['status']; ?>
                            </span>
                        </td>
                        <td class="px-6 py-5">
                            <a href="booking_details.php?id=<?php echo $booking['id']; ?>" class="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition inline-block">
                                <i data-lucide="edit-3" class="w-4 h-4"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
