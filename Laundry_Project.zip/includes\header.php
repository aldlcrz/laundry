<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Prevent Back Button (Cache Control)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Get current page and directory
$currentPage = basename($_SERVER['PHP_SELF']);
$currentDir = basename(dirname($_SERVER['PHP_SELF']));

$hideNavPages = ['login.php', 'register.php', 'forgot_password.php'];
$isAdminPage = ($currentDir === 'admin' || $currentDir === 'staff');

// Hide global nav on login/reg pages OR if we are on an admin/staff page
$showNav = !in_array($currentPage, $hideNavPages) && !$isAdminPage;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laundry Project - Premium Laundry Services</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3b82f6',
                        secondary: '#1e40af',
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 text-gray-800 font-sans antialiased flex flex-col min-h-screen">
    <?php if ($showNav): ?>
    <nav class="bg-white shadow-md fixed w-full z-50 transition-all duration-300">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Logo -->
                <div class="flex-shrink-0 flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-primary tracking-tight">
                        <i class="fas fa-tshirt mr-2"></i>Laundry Project
                    </a>
                </div>
                
                <!-- Desktop Menu -->
                <div class="hidden md:flex space-x-6 items-center">
                    <a href="index.php" class="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition">Home</a>
                    <a href="about.php" class="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition">About</a>
                    
                    <?php if(isset($_SESSION['user_id'])): 
                        // Ensure we have access to $pdo
                        if (!isset($pdo)) {
                            require_once __DIR__ . '/../config/db.php';
                        }
                        $notifStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
                        $notifStmt->execute([$_SESSION['user_id']]);
                        $unreadCount = $notifStmt->fetchColumn();
                    ?>
                        <a href="my_bookings.php" class="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition">My Bookings</a>
                        <a href="notifications.php" class="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition relative">
                            Notifications
                            <?php if ($unreadCount > 0): ?>
                            <span class="absolute -top-1 -right-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full ring-2 ring-white">
                                <?php echo $unreadCount; ?>
                            </span>
                            <?php endif; ?>
                        </a>
                        
                        <?php if($_SESSION['role'] === 'admin'): ?>
                            <a href="admin/dashboard.php" class="text-secondary font-semibold hover:text-blue-800 transition">Admin Panel</a>
                        <?php elseif($_SESSION['role'] === 'staff'): ?>
                            <a href="staff/dashboard.php" class="text-secondary font-semibold hover:text-blue-800 transition">Staff Panel</a>
                        <?php else: ?>
                            <a href="profile.php" class="text-secondary font-semibold hover:text-blue-800 transition">Profile</a>
                        <?php endif; ?>

                        <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full text-sm font-medium transition shadow-md">Logout</a>
                    <?php else: ?>
                        <a href="contact.php" class="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition">Contact</a>
                        <a href="login.php" class="text-gray-600 hover:text-primary px-3 py-2 text-sm font-medium transition">Login</a>
                        <a href="register.php" class="bg-primary hover:bg-secondary text-white px-5 py-2 rounded-full text-sm font-medium transition shadow-lg transform hover:-translate-y-0.5">Sign Up</a>
                    <?php endif; ?>

                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="booking.php" class="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 text-white px-6 py-2 rounded-full text-sm font-bold transition shadow-xl transform hover:scale-105 border border-blue-400">
                            Book Now
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    <div class="pt-16 flex-grow"> <!-- Spacer for fixed nav -->
    <?php else: ?>
    <div class="flex-grow">
    <?php endif; ?>
