<?php
session_start();
require_once 'config/db.php';
$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (empty($name) || empty($email) || empty($password) || empty($address)) {
        $error = "Please fill in all required fields.";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $error = "Name must only contain letters and spaces.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match("/@gmail\.com$/", $email)) {
        $error = "Only @gmail.com email addresses are accepted.";
    } elseif (!preg_match("/^[0-9]+$/", $phone)) {
        $error = "Phone number must only contain numbers.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (!isset($_POST['terms'])) {
        $error = "You must agree to the Terms & Privacy Policy.";
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Email already registered.";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $sql = "INSERT INTO users (name, email, phone, address, password, role) VALUES (?, ?, ?, ?, ?, 'customer')";
            $stmt = $pdo->prepare($sql);
            
            if ($stmt->execute([htmlspecialchars($name), $email, $phone, htmlspecialchars($address), $hashed_password])) {
                $success = "Registration successful! You can now login.";
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}

include 'includes/header.php';
?>

<div class="flex items-center justify-center min-h-[80vh] py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8 bg-white p-10 rounded-2xl shadow-xl border border-gray-100">
        <div>
            <h2 class="mt-2 text-center text-3xl font-extrabold text-gray-900">
                Create Account
            </h2>
            <p class="mt-2 text-center text-sm text-gray-600">
                Join Laundry Project today for premium laundry care
            </p>
        </div>
        
        <?php if($error): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded" role="alert">
                <p><?php echo $error; ?></p>
            </div>
        <?php endif; ?>
        
        <?php if($success): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded" role="alert">
                <p><?php echo $success; ?> <a href="login.php" class="font-bold underline">Login here</a>.</p>
            </div>
        <?php endif; ?>

        <form class="mt-8 space-y-6" action="" method="POST">
            <div class="rounded-md shadow-sm -space-y-px">
                <!-- Name -->
                <div>
                    <label for="name" class="sr-only">Full Name</label>
                    <input id="name" name="name" type="text" required pattern="[a-zA-Z\s]+" title="Real names only (letters/spaces)" class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" placeholder="Full Name (Letters only)">
                </div>
                
                <!-- Email & Phone -->
                <div class="grid grid-cols-2 gap-0">
                    <input id="email" name="email" type="email" required pattern=".*@gmail\.com$" title="Only @gmail.com addresses allowed" class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" placeholder="Gmail Address (@gmail.com)">
                    <input id="phone" name="phone" type="text" required pattern="[0-9]+" title="Numbers only" class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" placeholder="Phone Number (Digits)">
                </div>

                <!-- Address -->
                <div>
                    <label for="address" class="sr-only">Street Address</label>
                    <input id="address" name="address" type="text" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" placeholder="Full Address (Street, City, Province)">
                </div>

                <!-- Passwords -->
                <div>
                    <label for="password" class="sr-only">Password</label>
                    <input id="password" name="password" type="password" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" placeholder="Password">
                </div>
                <div>
                    <label for="confirm_password" class="sr-only">Confirm Password</label>
                    <input id="confirm_password" name="confirm_password" type="password" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" placeholder="Confirm Password">
                </div>
            </div>

            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <input id="terms" name="terms" type="checkbox" required class="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded">
                    <label for="terms" class="ml-2 block text-sm text-gray-900">
                        I agree to <a href="#" class="text-primary hover:text-secondary font-medium">Terms & Privacy Policy</a>
                    </label>
                </div>
            </div>

            <div>
                <button type="submit" class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition shadow-md">
                    <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                        <i class="fas fa-user-plus text-blue-300 group-hover:text-blue-200"></i>
                    </span>
                    Create Account
                </button>
            </div>

            <!-- Hidden Google Sign Up to prevent 401 Error until configured -->
            <!--
            <div class="relative py-4">
                <div class="absolute inset-0 flex items-center"><div class="w-full border-t border-gray-200"></div></div>
                <div class="relative flex justify-center text-sm"><span class="px-2 bg-white text-gray-500 font-medium tracking-tight">Or join with</span></div>
            </div>

            <div>
                <?php require_once 'config/google_auth.php'; ?>
                <a href="<?php echo getGoogleAuthURL(); ?>" class="w-full inline-flex justify-center py-2.5 px-4 rounded-md shadow-sm bg-white text-sm font-bold text-gray-700 hover:bg-gray-50 transition border border-gray-300">
                    <img class="h-5 w-5 mr-3" src="https://www.svgrepo.com/show/355037/google.svg" alt="Google logo">
                    Sign up with Google
                </a>
            </div>
            -->
            
            <div class="text-center text-sm">
                <p class="text-gray-600">Already have an account? <a href="login.php" class="font-medium text-primary hover:text-secondary">Sign in</a></p>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
