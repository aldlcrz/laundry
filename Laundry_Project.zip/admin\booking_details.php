<?php
require_once '../config/db.php';
session_start();

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'staff'])) {
    header("Location: ../login.php");
    exit;
}

$bookingId = $_GET['id'] ?? 0;

// Fetch booking with user and service details
$stmt = $pdo->prepare("
    SELECT b.*, u.name as user_name, u.email as user_email, u.phone as user_phone, 
           u.address, u.city, u.zip, s.service_name, s.base_price
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN services s ON b.service_id = s.id
    WHERE b.id = ?
");
$stmt->execute([$bookingId]);
$booking = $stmt->fetch();

if (!$booking) {
    die("Booking not found.");
}

// Fetch addons
$stmt = $pdo->prepare("SELECT * FROM additional_services WHERE booking_id = ?");
$stmt->execute([$bookingId]);
$addons = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Booking Details - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { theme: { extend: { fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'] }, colors: { primary: '#3b82f6' } } } }
    </script>
</head>
<body class="bg-[#f8fafc] font-sans antialiased text-gray-800">
    <?php include 'includes/sidebar.php'; ?>

    <div class="ml-64 p-8 min-h-screen">

<div class="max-w-4xl mx-auto py-8 px-4">
    <div class="mb-6 flex justify-between items-center">
        <div class="flex gap-4 items-center">
            <button onclick="history.back()" class="text-gray-600 hover:text-primary transition">
                <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
            </button>
            <span class="px-4 py-2 rounded-full font-bold text-sm 
                <?php echo $booking['status'] === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 
                       ($booking['status'] === 'Confirmed' ? 'bg-blue-100 text-blue-800' : 
                       ($booking['status'] === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800')); ?>">
                <?php echo $booking['status']; ?>
            </span>
        </div>
        <a href="../logout.php" class="bg-red-50 text-red-700 px-4 py-2 rounded-lg font-medium border border-red-200 hover:bg-red-100 transition">
            <i class="fas fa-sign-out-alt mr-2"></i>Logout
        </a>
    </div>

    <div class="bg-white shadow-xl rounded-2xl overflow-hidden border border-gray-100">
        <div class="bg-primary px-8 py-8 text-white relative overflow-hidden">
            <div class="relative z-10">
                <h2 class="text-3xl font-bold">Order #BK-<?php echo $booking['id']; ?></h2>
                <p class="text-blue-100 mt-1 font-medium opacity-80">Placed on <?php echo date('F j, Y', strtotime($booking['created_at'])); ?></p>
            </div>
            <i data-lucide="shopping-bag" class="absolute -right-4 top-0 w-32 h-32 text-white/10 -rotate-12"></i>
        </div>

        <div class="p-8 space-y-8">
            <!-- Customer & Service Section -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <h3 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Customer Information</h3>
                    <div class="space-y-2">
                        <p class="text-xl font-bold text-gray-900"><?php echo htmlspecialchars($booking['user_name']); ?></p>
                        <p class="text-gray-600"><i class="fas fa-envelope mr-2 w-5"></i><?php echo htmlspecialchars($booking['user_email']); ?></p>
                        <p class="text-gray-600"><i class="fas fa-phone mr-2 w-5"></i><?php echo htmlspecialchars($booking['user_phone']); ?></p>
                        <p class="text-gray-600"><i class="fas fa-map-marker-alt mr-2 w-5 text-primary"></i><?php echo htmlspecialchars($booking['address']); ?></p>
                    </div>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Service Details</h3>
                    <div class="space-y-2">
                        <p class="text-xl font-bold text-gray-900"><?php echo htmlspecialchars($booking['service_name']); ?></p>
                        <p class="text-gray-600"><i class="fas fa-calendar-day mr-2 w-5 text-primary"></i>Schedule: <b><?php echo date('F j, Y', strtotime($booking['booking_date'])); ?></b></p>
                        <p class="text-gray-600"><i class="fas fa-wallet mr-2 w-5 text-primary"></i>Method: <b><?php echo $booking['payment_method']; ?></b></p>
                    </div>
                </div>
            </div>

            <hr class="border-gray-100">

            <!-- Cost Breakdown -->
            <div>
                <h3 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Cost Breakdown</h3>
                <div class="space-y-3">
                    <div class="flex justify-between text-gray-700">
                        <span>Base Price (<?php echo htmlspecialchars($booking['service_name']); ?>)</span>
                        <span>₱<?php echo number_format($booking['base_price'], 2); ?></span>
                    </div>
                    <?php foreach ($addons as $addon): ?>
                    <div class="flex justify-between text-gray-700">
                        <span><i class="fas fa-plus-circle text-green-500 mr-2"></i><?php echo htmlspecialchars($addon['addon_name']); ?></span>
                        <span>₱<?php echo number_format($addon['price'], 2); ?></span>
                    </div>
                    <?php endforeach; ?>
                    <div class="flex justify-between border-t pt-4 mt-4">
                        <span class="text-xl font-bold text-gray-900">Total Amount</span>
                        <span class="text-2xl font-bold text-primary">₱<?php echo number_format($booking['total_amount'], 2); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-gray-50 px-8 py-6 border-t border-gray-100">
            <h3 class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Update Order Journey</h3>
            <div class="flex flex-wrap gap-3">
                <button onclick="updateStatus('Received')" class="bg-primary hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold transition shadow-lg shadow-blue-100 text-sm">Mark as Received</button>
                <button onclick="updateStatus('Completed')" class="bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-xl font-bold transition shadow-lg shadow-green-100 text-sm">Mark Completed</button>
                <button onclick="updateStatus('Cancelled')" class="bg-white hover:bg-red-50 text-red-600 px-5 py-2.5 rounded-xl font-bold transition border border-red-100 text-sm">Cancel Order</button>
            </div>
        </div>
    </div>
</div>

<script>
async function updateStatus(status) {
    if (!confirm(`Are you sure you want to mark this as ${status}?`)) return;
    
    const formData = new FormData();
    formData.append('booking_id', <?php echo $booking['id']; ?>);
    formData.append('status', status);

    const res = await fetch('api_update_status.php', { method: 'POST', body: formData });
    const result = await res.json();
    if (result.success) location.reload();
    else alert('Error: ' + result.message);
}
</script>

<?php include '../includes/footer.php'; ?>
