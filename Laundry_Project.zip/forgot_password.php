<?php
session_start();
require_once 'config/db.php';

$error = '';
$success = '';
$step = isset($_SESSION['reset_step']) ? $_SESSION['reset_step'] : 1;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Step 1: Check Email
    if (isset($_POST['identify_user'])) {
        $email = trim($_POST['email']);
        if (empty($email)) {
            $error = "Please enter your email.";
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->rowCount() > 0) {
                // Generate Code
                $code = rand(100000, 999999);
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_code'] = $code;
                $_SESSION['reset_step'] = 2;
                $step = 2;
                
                // In a real app, use mail() here. 
                // For XAMPP local testing, we show it in a success message.
                $success = "A verification code has been generated. <br>Code: <b>$code</b> (In production, this would be sent to $email)";
            } else {
                $error = "No account found with that email.";
            }
        }
    }
    
    // Step 2: Verify Code
    elseif (isset($_POST['verify_code'])) {
        $user_code = trim($_POST['code']);
        if ($user_code == $_SESSION['reset_code']) {
            $_SESSION['reset_step'] = 3;
            $step = 3;
        } else {
            $error = "Invalid verification code. Please try again.";
        }
    }
    
    // Step 3: Reset Password
    elseif (isset($_POST['reset_password'])) {
        $pass = $_POST['password'];
        $confirm = $_POST['confirm_password'];
        
        if (strlen($pass) < 8) {
            $error = "Password must be at least 8 characters.";
        } elseif ($pass !== $confirm) {
            $error = "Passwords do not match.";
        } else {
            $hashed = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
            if ($stmt->execute([$hashed, $_SESSION['reset_email']])) {
                // Done! Clear session and redirect
                unset($_SESSION['reset_email']);
                unset($_SESSION['reset_code']);
                unset($_SESSION['reset_step']);
                header("Location: login.php?reset=success");
                exit;
            } else {
                $error = "Error updating password.";
            }
        }
    }
}

// Reset flow if user wants to start over
if (isset($_GET['restart'])) {
    unset($_SESSION['reset_email']);
    unset($_SESSION['reset_code']);
    unset($_SESSION['reset_step']);
    header("Location: forgot_password.php");
    exit;
}

include 'includes/header.php';
?>

<div class="flex items-center justify-center min-h-[80vh] py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8 bg-white p-10 rounded-2xl shadow-xl border border-gray-100">
        <div class="text-center">
            <h2 class="text-3xl font-extrabold text-gray-900">Reset Password</h2>
            <p class="mt-2 text-sm text-gray-600">
                <?php 
                if($step == 1) echo "Enter your email to receive a verification code.";
                elseif($step == 2) echo "Enter the 6-digit code sent to your email.";
                else echo "Create a new secure password.";
                ?>
            </p>
        </div>

        <?php if($error): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded" role="alert">
                <p><?php echo $error; ?></p>
            </div>
        <?php endif; ?>

        <?php if($success): ?>
            <div class="bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 rounded" role="alert">
                <p><?php echo $success; ?></p>
            </div>
        <?php endif; ?>

        <form class="mt-8 space-y-6" action="" method="POST">
            
            <?php if ($step == 1): ?>
                <!-- STEP 1: Identification -->
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                    <input id="email" name="email" type="email" required class="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm mt-1" placeholder="yourname@gmail.com">
                </div>
                <button type="submit" name="identify_user" class="w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-secondary focus:outline-none transition">
                    Send Verification Code
                </button>

            <?php elseif ($step == 2): ?>
                <!-- STEP 2: Verification -->
                <div>
                    <label for="code" class="block text-sm font-medium text-gray-700">6-Digit Code</label>
                    <input id="code" name="code" type="text" maxlength="6" required class="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm mt-1 text-center text-xl tracking-widest font-bold" placeholder="000000">
                </div>
                <div class="flex flex-col gap-2">
                    <button type="submit" name="verify_code" class="w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none transition">
                        Verify Code
                    </button>
                    <a href="?restart=1" class="text-center text-xs text-gray-400 hover:text-gray-600">Didn't get a code? Try again</a>
                </div>

            <?php elseif ($step == 3): ?>
                <!-- STEP 3: New Password -->
                <div class="space-y-4">
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700">New Password</label>
                        <input id="password" name="password" type="password" required class="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm mt-1" placeholder="Min. 8 characters">
                    </div>
                    <div>
                        <label for="confirm_password" class="block text-sm font-medium text-gray-700">Confirm New Password</label>
                        <input id="confirm_password" name="confirm_password" type="password" required class="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm mt-1" placeholder="Repeat password">
                    </div>
                </div>
                <button type="submit" name="reset_password" class="w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none transition">
                    Change Password
                </button>
            <?php endif; ?>

            <div class="text-center text-sm mt-4">
                <a href="login.php" class="font-medium text-primary hover:text-secondary">Back to Login</a>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
