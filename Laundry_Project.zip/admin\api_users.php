<?php
require_once '../config/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_POST['action'] ?? '';
$userId = intval($_POST['user_id'] ?? 0);

if (!$userId) {
    echo json_encode(['success' => false, 'message' => 'Invalid User ID']);
    exit;
}

// Prevent self-deletion
if ($action === 'delete' && $userId == $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'message' => 'You cannot delete yourself!']);
    exit;
}

try {
    if ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        if ($stmt->execute([$userId])) {
            echo json_encode(['success' => true]);
        }
    } elseif ($action === 'toggle_role') {
        $newRole = $_POST['role']; // admin, staff, customer
        $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
        if ($stmt->execute([$newRole, $userId])) {
            echo json_encode(['success' => true]);
        }
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
