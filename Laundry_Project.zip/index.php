<?php
require_once 'config/db.php';
include 'includes/header.php';

// Fetch services
$stmt = $pdo->query("SELECT * FROM services");
$services = $stmt->fetchAll();

// Fetch Insights/Stats
$totalCompleted = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status = 'Completed'")->fetchColumn();
$totalOrders = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$totalHappyCustomers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();

// Add some "starting" numbers for a new shop if database is empty
$displayCompleted = max($totalCompleted, 1250);
$displayCustomers = max($totalHappyCustomers, 450);
$displayExperience = 5; // Years of experience
?>

<!-- Hero Section -->
<div class="relative bg-white overflow-hidden">
    <div class="max-w-7xl mx-auto">
        <div class="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
            <svg class="hidden lg:block absolute right-0 inset-y-0 h-full w-48 text-white transform translate-x-1/2" fill="currentColor" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                <polygon points="50,0 100,0 50,100 0,100" />
            </svg>

            <main class="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
                <div class="sm:text-center lg:text-left">
                    <h1 class="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                        <span class="block xl:inline">Premium Dry Cleaning</span>
                        <span class="block text-primary xl:inline">& Laundry Service</span>
                    </h1>
                    <p class="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                        We take care of your laundry so you can take care of your life. Affordable, quick, and high-quality service delivered to your doorstep.
                    </p>
                    <div class="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                        <div class="rounded-md shadow">
                            <a href="<?php echo isset($_SESSION['user_id']) ? 'booking.php' : 'login.php'; ?>" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary hover:bg-secondary md:py-4 md:text-lg transition transform hover:scale-105">
                                Book Now
                            </a>
                        </div>
                        <div class="mt-3 sm:mt-0 sm:ml-3">
                            <a href="#services" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-primary bg-blue-100 hover:bg-blue-200 md:py-4 md:text-lg transition">
                                View Services
                            </a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <div class="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
        <img class="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full" src="https://images.unsplash.com/photo-1545173168-9f1947eebb8f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2000&q=80" alt="Laundry Service">
    </div>
</div>

<!-- Services Section -->
<div id="services" class="py-12 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="lg:text-center">
            <h2 class="text-base text-primary font-semibold tracking-wide uppercase">Our Services</h2>
            <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                A Better Way to Do Laundry
            </p>
            <p class="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                Choose from our range of services tailored to your needs.
            </p>
        </div>

        <div class="mt-10">
            <div class="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
                <?php foreach ($services as $service): ?>
                <div class="relative bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-300 transform hover:-translate-y-1">
                    <div class="absolute flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                        <!-- Icon logic based on service name -->
                        <?php 
                            $icon = 'fa-tshirt';
                            if (stripos($service['service_name'], 'iron') !== false) $icon = 'fa-burn';
                            if (stripos($service['service_name'], 'dry') !== false) $icon = 'fa-wind';
                        ?>
                        <i class="fas <?php echo $icon; ?> fa-lg"></i>
                    </div>
                    <div class="ml-16">
                        <h3 class="text-lg leading-6 font-medium text-gray-900"><?php echo htmlspecialchars($service['service_name']); ?></h3>
                        <p class="mt-2 text-base text-gray-500">
                            <?php echo htmlspecialchars($service['description']); ?>
                        </p>
                        <p class="mt-4 text-2xl font-bold text-primary">
                            ₱<?php echo number_format($service['base_price'], 2); ?>
                        </p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Insights/Stats Section -->
<div class="bg-primary py-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div class="space-y-2">
                <div class="text-4xl font-extrabold text-white">
                    <?php echo number_format($displayCompleted); ?>+
                </div>
                <div class="text-blue-100 text-sm font-semibold uppercase tracking-wider">Orders Completed</div>
            </div>
            <div class="space-y-2">
                <div class="text-4xl font-extrabold text-white">
                    <?php echo number_format($displayCustomers); ?>+
                </div>
                <div class="text-blue-100 text-sm font-semibold uppercase tracking-wider">Happy Customers</div>
            </div>
            <div class="space-y-2">
                <div class="text-4xl font-extrabold text-white">
                    100%
                </div>
                <div class="text-blue-100 text-sm font-semibold uppercase tracking-wider">Satisfaction Rate</div>
            </div>
            <div class="space-y-2">
                <div class="text-4xl font-extrabold text-white">
                    <?php echo $displayExperience; ?>+
                </div>
                <div class="text-blue-100 text-sm font-semibold uppercase tracking-wider">Years Experience</div>
            </div>
        </div>
    </div>
</div>

<!-- Insights Detailed Section -->
<div class="py-16 bg-white overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
            <div class="relative">
                <h2 class="text-base text-primary font-semibold tracking-wide uppercase">Laundry Insight</h2>
                <h3 class="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl">Why we are the best choice for your clothes</h3>
                <p class="mt-4 text-lg text-gray-500">
                    We use a data-driven approach to ensure every garment receives the optimal cleaning treatment. Our system tracks thousands of bookings to improve efficiency and turnaround time.
                </p>
                <div class="mt-8 space-y-4">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <span class="flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-primary">
                                <i class="fas fa-check"></i>
                            </span>
                        </div>
                        <div class="ml-4">
                            <p class="text-lg font-medium text-gray-900">Advanced Fabric Analysis</p>
                            <p class="text-gray-500 italic">We identify fabric types automatically to prevent damage.</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <span class="flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-primary">
                                <i class="fas fa-bolt"></i>
                            </span>
                        </div>
                        <div class="ml-4">
                            <p class="text-lg font-medium text-gray-900">Next-Day Delivery Guarantee</p>
                            <p class="text-gray-500 italic">98% of our orders are delivered within 24 hours.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-12 lg:mt-0 relative">
                <div class="bg-blue-50 rounded-3xl p-8 border border-blue-100 shadow-inner">
                    <div class="flex items-center justify-between mb-6">
                        <h4 class="font-bold text-gray-800">Operational Insights</h4>
                        <span class="text-xs font-bold text-blue-500 px-2 py-1 bg-white rounded-md shadow-sm">LIVE UPDATES</span>
                    </div>
                    <div class="space-y-6">
                        <div>
                            <div class="flex justify-between text-sm font-bold mb-2">
                                <span class="text-gray-600">Customer Retention</span>
                                <span class="text-primary">92%</span>
                            </div>
                            <div class="w-full bg-blue-200 rounded-full h-2">
                                <div class="bg-primary h-2 rounded-full" style="width: 92%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between text-sm font-bold mb-2">
                                <span class="text-gray-600">On-Time Pickup</span>
                                <span class="text-green-500">99.4%</span>
                            </div>
                            <div class="w-full bg-green-200 rounded-full h-2">
                                <div class="bg-green-500 h-2 rounded-full" style="width: 99.4%"></div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-4 mt-8">
                            <div class="bg-white p-4 rounded-2xl shadow-sm border border-blue-50">
                                <span class="block text-[10px] font-bold text-gray-400 uppercase">Avg. Price</span>
                                <span class="text-xl font-bold text-gray-800">₱280.00</span>
                            </div>
                            <div class="bg-white p-4 rounded-2xl shadow-sm border border-blue-50">
                                <span class="block text-[10px] font-bold text-gray-400 uppercase">Daily Orders</span>
                                <span class="text-xl font-bold text-gray-800">45+</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CTA Section -->
<div class="bg-secondary">
    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
        <h2 class="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span class="block">Ready to get started?</span>
            <span class="block text-blue-200">Book your first laundry pickup today.</span>
        </h2>
        <div class="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div class="inline-flex rounded-md shadow">
                <a href="<?php echo isset($_SESSION['user_id']) ? 'booking.php' : 'login.php'; ?>" class="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-secondary bg-white hover:bg-gray-50">
                    Get Started
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
