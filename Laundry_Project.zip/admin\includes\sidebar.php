<?php
// admin/includes/sidebar.php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!-- Sidebar -->
<div class="fixed left-0 top-0 h-full w-64 bg-white border-r border-gray-100 z-50 flex flex-col shadow-sm">
    <!-- Brand -->
    <div class="p-6 border-b border-gray-50 flex items-center gap-3">
        <div class="h-10 w-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
            <i data-lucide="waves" class="w-6 h-6"></i>
        </div>
        <span class="text-xl font-black text-gray-900 tracking-tighter">Laundry Project</span>
    </div>

    <!-- Nav Links -->
    <div class="flex-grow p-4 space-y-2 overflow-y-auto">
        <p class="text-[11px] font-bold text-gray-400 uppercase tracking-widest px-4 mb-2">Main Menu</p>
        
        <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all group <?php echo $currentPage == 'dashboard.php' ? 'bg-blue-50 text-primary shadow-sm' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'; ?>">
            <i data-lucide="layout-dashboard" class="w-5 h-5 <?php echo $currentPage == 'dashboard.php' ? 'text-primary' : 'text-gray-400 group-hover:text-gray-700'; ?>"></i>
            <span class="font-medium">Dashboard</span>
        </a>

        <!-- Manage Bookings Dropdown -->
        <div class="relative" id="bookings-menu">
            <button onclick="toggleSubmenu('bookings-submenu')" class="w-full flex items-center justify-between px-4 py-3 rounded-xl text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-all group">
                <div class="flex items-center gap-3">
                    <i data-lucide="calendar-check" class="w-5 h-5 text-gray-400 group-hover:text-gray-700"></i>
                    <span class="font-medium">Manage Bookings</span>
                </div>
                <i data-lucide="chevron-down" class="w-4 h-4 transition-transform" id="bookings-arrow"></i>
            </button>
            <div id="bookings-submenu" class="hidden pl-12 pr-4 py-2 space-y-1">
                <a href="bookings.php" class="block py-2 text-sm text-gray-500 hover:text-primary transition">All Bookings</a>
                <a href="bookings.php?status=Pending" class="block py-2 text-sm text-gray-500 hover:text-primary transition">Pending Orders</a>
                <a href="bookings.php?status=Received" class="block py-2 text-sm text-gray-500 hover:text-primary transition">Received Orders</a>
                <a href="bookings.php?status=Completed" class="block py-2 text-sm text-gray-500 hover:text-primary transition">Completed Orders</a>
            </div>
        </div>

        <a href="staffs.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all group <?php echo $currentPage == 'staffs.php' ? 'bg-blue-50 text-primary shadow-sm' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'; ?>">
            <i data-lucide="users" class="w-5 h-5 <?php echo $currentPage == 'staffs.php' ? 'text-primary' : 'text-gray-400 group-hover:text-gray-700'; ?>"></i>
            <span class="font-medium">Manage Staffs</span>
        </a>

        <a href="admins.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all group <?php echo $currentPage == 'admins.php' ? 'bg-blue-50 text-primary shadow-sm' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'; ?>">
            <i data-lucide="shield-check" class="w-5 h-5 <?php echo $currentPage == 'admins.php' ? 'text-primary' : 'text-gray-400 group-hover:text-gray-700'; ?>"></i>
            <span class="font-medium">Manage Admins</span>
        </a>

        <a href="manage_services.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all group <?php echo $currentPage == 'manage_services.php' ? 'bg-blue-50 text-primary shadow-sm' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'; ?>">
            <i data-lucide="sparkles" class="w-5 h-5 <?php echo $currentPage == 'manage_services.php' ? 'text-primary' : 'text-gray-400 group-hover:text-gray-700'; ?>"></i>
            <span class="font-medium">Price Management</span>
        </a>
    </div>

    <!-- Bottom Actions -->
    <div class="p-4 border-t border-gray-50">
        <a href="../logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-all group font-bold">
            <i data-lucide="log-out" class="w-5 h-5"></i>
            <span>Logout</span>
        </a>
    </div>
</div>

<script>
function toggleSubmenu(id) {
    const submenu = document.getElementById(id);
    const arrow = document.getElementById(id.replace('submenu', 'arrow'));
    const isHidden = submenu.classList.contains('hidden');
    
    // Close all first (optional)
    // document.querySelectorAll('[id$="-submenu"]').forEach(el => el.classList.add('hidden'));
    
    if (isHidden) {
        submenu.classList.remove('hidden');
        arrow.style.transform = 'rotate(180deg)';
    } else {
        submenu.classList.add('hidden');
        arrow.style.transform = 'rotate(0deg)';
    }
}
</script>
