<?php
// google_callback.php
session_start();
require_once 'config/db.php';
require_once 'config/google_auth.php';

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // 1. Exchange code for access token
    $token_url = "https://oauth2.googleapis.com/token";
    $params = [
        'code' => $code,
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'redirect_uri' => GOOGLE_REDIRECT_URL,
        'grant_type' => 'authorization_code'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $token_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['access_token'])) {
        $access_token = $data['access_token'];

        // 2. Get user info
        $user_info_url = "https://www.googleapis.com/oauth2/v2/userinfo?access_token=" . $access_token;
        $user_info_response = file_get_contents($user_info_url);
        $user_info = json_decode($user_info_response, true);

        if (isset($user_info['id'])) {
            $google_id = $user_info['id'];
            $name = $user_info['name'];
            $email = $user_info['email'];

            // 3. Check if user exists
            $stmt = $pdo->prepare("SELECT * FROM users WHERE google_id = ? OR email = ?");
            $stmt->execute([$google_id, $email]);
            $user = $stmt->fetch();

            if ($user) {
                // Update google_id if it was found by email but had no ID
                if (!$user['google_id']) {
                    $upd = $pdo->prepare("UPDATE users SET google_id = ? WHERE id = ?");
                    $upd->execute([$google_id, $user['id']]);
                }
            } else {
                // 4. Register new user
                $ins = $pdo->prepare("INSERT INTO users (google_id, name, email, role) VALUES (?, ?, ?, 'customer')");
                $ins->execute([$google_id, $name, $email]);
                
                $stmt = $pdo->prepare("SELECT * FROM users WHERE google_id = ?");
                $stmt->execute([$google_id]);
                $user = $stmt->fetch();
            }

            // 5. Start Session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            // Redirect
            if ($user['role'] === 'admin') {
                header("Location: admin/dashboard.php");
            } elseif ($user['role'] === 'staff') {
                header("Location: staff/dashboard.php");
            } else {
                header("Location: index.php");
            }
            exit;
        }
    }
}

// If something failed
header("Location: login.php?error=google_failed");
exit;
