<?php
// config/google_auth.php

// Google API Credentials
// Get these from: https://console.cloud.google.com/
define('GOOGLE_CLIENT_ID', 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');

// The URL where Google will redirect after login
// For Local: http://localhost/Laundry/google_callback.php
// For Live: https://laundryproject.xo.je/google_callback.php
define('GOOGLE_REDIRECT_URL', 'https://laundryproject.xo.je/google_callback.php');

function getGoogleAuthURL() {
    $params = [
        'response_type' => 'code',
        'client_id' => GOOGLE_CLIENT_ID,
        'redirect_uri' => GOOGLE_REDIRECT_URL,
        'scope' => 'https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email',
        'access_type' => 'offline',
        'prompt' => 'select_account'
    ];
    
    return "https://accounts.google.com/o/oauth2/v2/auth?" . http_build_query($params);
}
