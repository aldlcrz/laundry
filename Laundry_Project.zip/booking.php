<?php
require_once 'config/db.php';
// Check login
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include 'includes/header.php';

// Fetch Services for JS
$stmt = $pdo->query("SELECT * FROM services");
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <div class="text-center mb-10">
        <h1 class="text-3xl font-extrabold text-gray-900">Book a Laundry Slot</h1>
        <p class="mt-2 text-gray-600">Select a date to schedule your pickup.</p>
    </div>

    <!-- Calendar Container -->
    <div class="bg-white shadow overflow-hidden sm:rounded-lg max-w-4xl mx-auto">
        <div class="px-4 py-5 sm:px-6 flex justify-between items-center">
            <h3 class="text-lg leading-6 font-medium text-gray-900" id="currentMonthYear">
                <!-- Javascript will populate this -->
            </h3>
            <div class="flex space-x-2">
                <button id="prevMonth" class="p-2 rounded-full hover:bg-gray-100"><i class="fas fa-chevron-left"></i></button>
                <button id="nextMonth" class="p-2 rounded-full hover:bg-gray-100"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
        <div class="border-t border-gray-200 p-4">
            <div class="grid grid-cols-7 gap-2 text-center text-sm font-semibold text-gray-700 mb-2">
                <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
            </div>
            <div id="calendarDays" class="grid grid-cols-7 gap-2">
                <!-- JS renders days here -->
            </div>
        </div>
    </div>
</div>

<!-- Booking Modal -->
<div id="bookingModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <!-- Overlay -->
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" onclick="closeModal()"></div>

        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4" id="modal-title">
                    Book Service for <span id="selectedDateText" class="text-primary font-bold"></span>
                </h3>
                
                <form id="bookingForm" class="space-y-4">
                    <input type="hidden" id="selectedDate" name="date">
                    
                    <!-- Services -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Select Service</label>
                        <div class="space-y-2">
                            <?php foreach($services as $service): ?>
                            <div class="flex items-center">
                                <input id="service_<?php echo $service['id']; ?>" name="service_id" type="radio" value="<?php echo $service['id']; ?>" data-price="<?php echo $service['base_price']; ?>" class="focus:ring-primary h-4 w-4 text-primary border-gray-300" required onchange="calculateTotal()">
                                <label for="service_<?php echo $service['id']; ?>" class="ml-3 block text-sm font-medium text-gray-700">
                                    <?php echo htmlspecialchars($service['service_name']); ?> 
                                    <span class="text-gray-500">- ₱<?php echo number_format($service['base_price'], 2); ?></span>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Add-ons -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Add-ons</label>
                        <div class="grid grid-cols-2 gap-2">
                            <div class="flex items-center">
                                <input id="addon_wash" name="addons[]" type="checkbox" value="Extra Wash" data-price="150" class="focus:ring-primary h-4 w-4 text-primary border-gray-300 rounded" onchange="calculateTotal()">
                                <label for="addon_wash" class="ml-2 block text-sm text-gray-900">Extra Wash (+₱150)</label>
                            </div>
                            <div class="flex items-center">
                                <input id="addon_dry" name="addons[]" type="checkbox" value="Extra Dry" data-price="120" class="focus:ring-primary h-4 w-4 text-primary border-gray-300 rounded" onchange="calculateTotal()">
                                <label for="addon_dry" class="ml-2 block text-sm text-gray-900">Extra Dry (+₱120)</label>
                            </div>
                             <div class="flex items-center">
                                <input id="addon_rinse" name="addons[]" type="checkbox" value="Extra Rinse" data-price="100" class="focus:ring-primary h-4 w-4 text-primary border-gray-300 rounded" onchange="calculateTotal()">
                                <label for="addon_rinse" class="ml-2 block text-sm text-gray-900">Extra Rinse (+₱100)</label>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Method (Fixed) -->
                    <div class="bg-blue-50 p-4 rounded-xl border border-blue-100 flex items-center justify-between">
                        <div>
                            <span class="block text-xs font-bold text-blue-400 uppercase tracking-widest leading-none mb-1">Payment Method</span>
                            <span class="text-sm font-bold text-gray-800">Cash on Pickup / COD</span>
                        </div>
                        <div class="h-10 w-10 bg-white rounded-full flex items-center justify-center text-blue-500 shadow-sm">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <input type="hidden" name="payment_method" value="Cash on Pickup">
                    </div>

                    <!-- Total -->
                    <div class="border-t pt-4 mt-4">
                        <div class="flex justify-between items-center text-lg font-bold">
                            <span>Total Amount:</span>
                            <span class="text-primary" id="totalDisplay">₱0.00</span>
                            <input type="hidden" name="total_amount" id="totalInput" value="0">
                        </div>
                    </div>
                </form>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button type="button" onclick="submitBooking()" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-primary text-base font-medium text-white hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:ml-3 sm:w-auto sm:text-sm">
                    Confirm Booking
                </button>
                <button type="button" onclick="closeModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    Cancel
                </button>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/book.js"></script>

<?php include 'includes/footer.php'; ?>
