<?php
require_once 'config/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Get all bookings for this user
$stmt = $pdo->prepare("
    SELECT b.*, s.service_name 
    FROM bookings b 
    JOIN services s ON b.service_id = s.id 
    WHERE b.user_id = ? 
    ORDER BY b.created_at DESC
");
$stmt->execute([$userId]);
$bookings = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-extrabold text-gray-900">My Bookings</h1>
            <p class="mt-2 text-gray-600">Track and manage your laundry appointments.</p>
        </div>
        <a href="booking.php" class="bg-primary hover:bg-secondary text-white px-6 py-2 rounded-full font-bold transition shadow-lg transform hover:scale-105">
            Book New Slot
        </a>
    </div>

    <?php if (empty($bookings)): ?>
        <div class="bg-white rounded-2xl shadow-xl p-12 text-center border border-gray-100">
            <div class="mx-auto h-24 w-24 text-gray-200 mb-4">
                <i class="fas fa-calendar-times fa-5x"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-900">No bookings yet</h2>
            <p class="text-gray-500 mt-2">You haven't scheduled any laundry services yet. Start today!</p>
            <div class="mt-8">
                <a href="booking.php" class="text-primary font-bold hover:underline">Go to Booking Calendar →</a>
            </div>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($bookings as $booking): 
                $statusColor = 'bg-orange-100 text-orange-700'; // Pending
                if($booking['status'] == 'Received') $statusColor = 'bg-blue-100 text-blue-700';
                if($booking['status'] == 'Completed') $statusColor = 'bg-green-100 text-green-700';
                if($booking['status'] == 'Cancelled') $statusColor = 'bg-red-100 text-red-700';
            ?>
            <div class="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 transition hover:shadow-xl">
                <div class="px-6 py-4 bg-gray-50 border-b flex justify-between items-center">
                    <span class="text-xs font-bold text-gray-400">#BK-<?php echo $booking['id']; ?></span>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-bold <?php echo $statusColor; ?>">
                        <?php echo $booking['status']; ?>
                    </span>
                </div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-1"><?php echo htmlspecialchars($booking['service_name']); ?></h3>
                    <p class="text-gray-500 text-sm mb-4"><i class="fas fa-calendar-alt mr-2 text-primary"></i><?php echo date('F j, Y', strtotime($booking['booking_date'])); ?></p>
                    
                    <div class="flex justify-between items-center mt-6 pt-4 border-t border-gray-50">
                        <div class="text-sm">
                            <span class="text-gray-500">Total:</span>
                            <span class="font-bold text-gray-900">₱<?php echo number_format($booking['total_amount'], 2); ?></span>
                        </div>
                        <span class="text-xs text-gray-400"><?php echo $booking['payment_method']; ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
