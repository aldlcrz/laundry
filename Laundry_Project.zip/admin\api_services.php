<?php
require_once '../config/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_POST['action'] ?? '';

try {
    if ($action === 'add') {
        $name = trim($_POST['service_name']);
        $price = floatval($_POST['base_price']);
        $desc = trim($_POST['description']);
        
        $stmt = $pdo->prepare("INSERT INTO services (service_name, base_price, description) VALUES (?, ?, ?)");
        if ($stmt->execute([$name, $price, $desc])) {
            echo json_encode(['success' => true]);
        }
    } elseif ($action === 'edit') {
        $id = intval($_POST['service_id']);
        $name = trim($_POST['service_name']);
        $price = floatval($_POST['base_price']);
        $desc = trim($_POST['description']);
        
        $stmt = $pdo->prepare("UPDATE services SET service_name = ?, base_price = ?, description = ? WHERE id = ?");
        if ($stmt->execute([$name, $price, $desc, $id])) {
            echo json_encode(['success' => true]);
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['service_id']);
        $stmt = $pdo->prepare("DELETE FROM services WHERE id = ?");
        if ($stmt->execute([$id])) {
            echo json_encode(['success' => true]);
        }
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
