<?php
require_once '../config/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId = $_POST['booking_id'];
    $status = $_POST['status'];

    if (empty($bookingId) || empty($status)) {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
        exit;
    }

    try {
        $pdo->beginTransaction();

        $sql = "UPDATE bookings SET status = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        
        if ($stmt->execute([$status, $bookingId])) {
            // Get user_id for notification
            $stmt = $pdo->prepare("SELECT user_id FROM bookings WHERE id = ?");
            $stmt->execute([$bookingId]);
            $booking = $stmt->fetch();
            
            if ($booking) {
                $userId = $booking['user_id'];
                $title = "Order Status Updated";
                $message = "Your laundry order #BK-$bookingId is now $status.";
                
                $notifSql = "INSERT INTO notifications (user_id, booking_id, title, message) VALUES (?, ?, ?, ?)";
                $notifStmt = $pdo->prepare($notifSql);
                $notifStmt->execute([$userId, $bookingId, $title, $message]);
            }

            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Status updated successfully']);
        } else {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'Failed to update status']);
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>
