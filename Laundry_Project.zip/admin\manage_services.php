<?php
require_once '../config/db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Fetch all services
$stmt = $pdo->query("SELECT * FROM services ORDER BY created_at DESC");
$services = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
    <div class="px-4 py-6 sm:px-0">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold text-gray-900">Manage Services</h1>
            <div class="flex gap-3">
                <a href="dashboard.php" class="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg font-medium border border-blue-200 hover:bg-blue-100 transition">
                    <i class="fas fa-calendar-alt mr-2"></i>Bookings
                </a>
                <button onclick="openModal('add')" class="bg-primary hover:bg-secondary text-white px-4 py-2 rounded-lg font-medium transition shadow-md">
                    <i class="fas fa-plus mr-2"></i>Add Service
                </button>
                <a href="../logout.php" class="bg-red-50 text-red-700 px-4 py-2 rounded-lg font-medium border border-red-200 hover:bg-red-100 transition ml-4">
                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                </a>
            </div>
        </div>
        
        <div class="bg-white shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($services as $service): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            <?php echo htmlspecialchars($service['service_name']); ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500">
                            <?php echo htmlspecialchars($service['description']); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            ₱<?php echo number_format($service['base_price'], 2); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onclick='openModal("edit", <?php echo json_encode($service); ?>)' class="text-indigo-600 hover:text-indigo-900 mr-4">Edit</button>
                            <button onclick="deleteService(<?php echo $service['id']; ?>)" class="text-red-600 hover:text-red-900">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="serviceModal" class="fixed inset-0 z-50 hidden overflow-y-auto">
    <div class="flex items-center justify-center min-h-screen px-4">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75" onclick="closeModal()"></div>
        <div class="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all sm:max-w-lg sm:w-full">
            <form id="serviceForm" onsubmit="handleFormSubmit(event)">
                <div class="px-6 py-4 border-b">
                    <h3 class="text-lg font-medium text-gray-900" id="modalTitle">Add Service</h3>
                </div>
                <div class="px-6 py-4 space-y-4">
                    <input type="hidden" id="serviceId">
                    <input type="hidden" id="formAction" value="add">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Service Name</label>
                        <input type="text" id="serviceName" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Description</label>
                        <textarea id="serviceDesc" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Price (₱)</label>
                        <input type="number" step="0.01" id="servicePrice" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                    </div>
                </div>
                <div class="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onclick="closeModal()" class="text-gray-700 px-4 py-2 border rounded-md">Cancel</button>
                    <button type="submit" class="bg-primary text-white px-4 py-2 rounded-md hover:bg-secondary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(action, data = null) {
    document.getElementById('serviceModal').classList.remove('hidden');
    document.getElementById('formAction').value = action;
    document.getElementById('modalTitle').innerText = action === 'add' ? 'Add New Service' : 'Edit Service';
    
    if (data) {
        document.getElementById('serviceId').value = data.id;
        document.getElementById('serviceName').value = data.service_name;
        document.getElementById('serviceDesc').value = data.description;
        document.getElementById('servicePrice').value = data.base_price;
    } else {
        document.getElementById('serviceForm').reset();
    }
}

function closeModal() {
    document.getElementById('serviceModal').classList.add('hidden');
}

async function handleFormSubmit(e) {
    e.preventDefault();
    const action = document.getElementById('formAction').value;
    const formData = new FormData();
    formData.append('action', action);
    formData.append('service_id', document.getElementById('serviceId').value);
    formData.append('service_name', document.getElementById('serviceName').value);
    formData.append('description', document.getElementById('serviceDesc').value);
    formData.append('base_price', document.getElementById('servicePrice').value);

    const res = await fetch('api_services.php', { method: 'POST', body: formData });
    const result = await res.json();
    if (result.success) location.reload();
    else alert('Error: ' + result.message);
}

async function deleteService(id) {
    if (!confirm('Are you sure you want to delete this service?')) return;
    const formData = new FormData();
    formData.append('action', 'delete');
    formData.append('service_id', id);
    
    const res = await fetch('api_services.php', { method: 'POST', body: formData });
    const result = await res.json();
    if (result.success) location.reload();
    else alert('Error: ' + result.message);
}
</script>

<?php include '../includes/footer.php'; ?>
