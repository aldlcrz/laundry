<?php
require_once '../config/db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];

    if (empty($name) || empty($email) || empty($password)) {
        $error = "Name, Email, and Password are required.";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $error = "Name must only contain letters and spaces.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match("/@gmail\.com$/", $email)) {
        $error = "Only @gmail.com email addresses are accepted.";
    } elseif (!preg_match("/^[0-9]+$/", $phone)) {
        $error = "Phone number must only contain numbers.";
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email already registered.";
        } else {
            // Hash password and insert
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, 'staff')");
            
            if ($stmt->execute([$name, $email, $phone, $hashed_password])) {
                $success = "Staff account created successfully!";
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Create Staff - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { theme: { extend: { fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'] }, colors: { primary: '#3b82f6' } } } }
    </script>
</head>
<body class="bg-[#f8fafc] font-sans antialiased text-gray-800">
    <?php include 'includes/sidebar.php'; ?>

    <div class="ml-64 p-8 min-h-screen">
        <div class="max-w-2xl mx-auto">
            <div class="mb-8 flex items-center gap-4">
                <button onclick="history.back()" class="p-2 bg-white border border-gray-100 rounded-xl text-gray-400 hover:text-primary transition shadow-sm">
                    <i data-lucide="arrow-left" class="w-5 h-5"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Add New Staff</h1>
                    <p class="text-gray-500 text-sm mt-1">Create a new service account for your personnel.</p>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-100 text-red-600 rounded-2xl text-sm font-medium flex items-center gap-3">
                    <i data-lucide="alert-circle" class="w-5 h-5"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-100 text-green-600 rounded-2xl text-sm font-medium flex items-center gap-3">
                    <i data-lucide="check-circle" class="w-5 h-5"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <div class="bg-white rounded-3xl border border-gray-100 shadow-sm p-8">
                <form action="" method="POST" class="space-y-6">
                    <div>
                        <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Full Name</label>
                        <input type="text" name="name" required pattern="[a-zA-Z\s]+" title="Letters only" placeholder="Enter staff name (Letters only)" class="w-full px-4 py-3 bg-gray-50 border border-transparent rounded-xl focus:bg-white focus:border-blue-100 focus:ring-4 focus:ring-blue-50 outline-none transition duration-200">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Email Address</label>
                        <input type="email" name="email" required pattern=".*@gmail\.com$" title="Only @gmail.com addresses allowed" placeholder="staff@gmail.com" class="w-full px-4 py-3 bg-gray-50 border border-transparent rounded-xl focus:bg-white focus:border-blue-100 focus:ring-4 focus:ring-blue-50 outline-none transition duration-200">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Phone Number</label>
                        <input type="text" name="phone" pattern="[0-9]+" title="Numbers only" placeholder="Phone Number (Digits only)" class="w-full px-4 py-3 bg-gray-50 border border-transparent rounded-xl focus:bg-white focus:border-blue-100 focus:ring-4 focus:ring-blue-50 outline-none transition duration-200">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Login Password</label>
                        <input type="password" name="password" required placeholder="••••••••" class="w-full px-4 py-3 bg-gray-50 border border-transparent rounded-xl focus:bg-white focus:border-blue-100 focus:ring-4 focus:ring-blue-50 outline-none transition duration-200">
                    </div>

                    <button type="submit" class="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-100 hover:bg-blue-600 transition active:scale-[0.98]">
                        Create Account
                    </button>
                </form>
            </div>
        </div>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
