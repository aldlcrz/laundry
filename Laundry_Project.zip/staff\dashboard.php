<?php
require_once '../config/db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit;
}

$statusFilter = $_GET['view'] ?? 'pending'; // pending, received, completed

// Define statuses for each view
$views = [
    'pending' => ['Pending'],
    'received' => ['Received'],
    'completed' => ['Completed']
];

$currentStatuses = $views[$statusFilter] ?? $views['pending'];
$statusList = "'" . implode("','", $currentStatuses) . "'";

// Fetch bookings for this view
$stmt = $pdo->query("
    SELECT b.*, u.name as user_name, u.phone as user_phone, u.address, s.service_name 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN services s ON b.service_id = s.id
    WHERE b.status IN ($statusList)
    ORDER BY b.booking_date ASC
");
$bookings = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'] },
                    colors: { primary: '#3b82f6', secondary: '#1e40af' }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 font-sans antialiased text-gray-800">

    <!-- Header -->
    <header class="bg-white border-b border-gray-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
            <div class="flex items-center gap-2">
                <div class="h-8 w-8 bg-primary rounded-lg flex items-center justify-center text-white shadow-lg shadow-blue-100">
                    <i data-lucide="waves" class="w-5 h-5"></i>
                </div>
                <span class="text-lg font-bold text-gray-900">Staff Panel</span>
            </div>
            <div class="flex items-center gap-6">
                <nav class="hidden md:flex gap-1">
                    <a href="?view=pending" class="px-4 py-2 rounded-lg text-sm font-bold <?php echo $statusFilter == 'pending' ? 'bg-blue-50 text-primary' : 'text-gray-500 hover:bg-gray-50'; ?>">Pending</a>
                    <a href="?view=received" class="px-4 py-2 rounded-lg text-sm font-bold <?php echo $statusFilter == 'received' ? 'bg-blue-50 text-primary' : 'text-gray-500 hover:bg-gray-50'; ?>">Received</a>
                    <a href="?view=completed" class="px-4 py-2 rounded-lg text-sm font-bold <?php echo $statusFilter == 'completed' ? 'bg-blue-50 text-primary' : 'text-gray-500 hover:bg-gray-50'; ?>">Completed</a>
                </nav>
                <div class="h-8 border-l border-gray-100"></div>
                <a href="../logout.php" class="text-sm font-bold text-red-500 hover:text-red-600 flex items-center gap-2">
                    <i data-lucide="log-out" class="w-4 h-4"></i> Logout
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 py-10">
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900 capitalize"><?php echo $statusFilter; ?> Orders</h1>
            <p class="text-gray-500 mt-1">Found <?php echo count($bookings); ?> orders in this section.</p>
        </div>

        <?php if (empty($bookings)): ?>
        <div class="bg-white rounded-3xl border border-gray-100 p-20 text-center shadow-sm">
            <div class="mx-auto h-20 w-20 bg-gray-50 rounded-full flex items-center justify-center text-gray-300 mb-4">
                <i data-lucide="package-search" class="w-10 h-10"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-900 border-none">All clear!</h2>
            <p class="text-gray-500">No <?php echo $statusFilter; ?> orders at the moment.</p>
        </div>
        <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($bookings as $booking): 
                $statusColor = 'bg-orange-100 text-orange-700'; // Pending
                if ($booking['status'] == 'Received') $statusColor = 'bg-blue-100 text-blue-700';
                if ($booking['status'] == 'Completed') $statusColor = 'bg-green-100 text-green-700';
                if ($booking['status'] == 'Cancelled') $statusColor = 'bg-red-100 text-red-700';
            ?>
            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col hover:shadow-md transition-shadow">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-4">
                        <span class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">#BK-<?php echo $booking['id']; ?></span>
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold <?php echo $statusColor; ?>"><?php echo $booking['status']; ?></span>
                    </div>
                    <div class="flex justify-between items-center mb-1">
                        <h3 class="text-lg font-bold text-gray-900"><?php echo htmlspecialchars($booking['user_name']); ?></h3>
                        <a href="../admin/booking_details.php?id=<?php echo $booking['id']; ?>" class="text-xs text-primary hover:underline font-bold">Details <i data-lucide="external-link" class="w-3 h-3 inline"></i></a>
                    </div>
                    <p class="text-gray-500 text-sm mb-4"><i data-lucide="map-pin" class="w-3 h-3 inline mr-1"></i><?php echo htmlspecialchars($booking['address']); ?></p>
                    
                    <div class="bg-slate-50 rounded-xl p-4 mb-4">
                        <div class="flex justify-between text-xs mb-1">
                            <span class="text-gray-400">Service</span>
                            <span class="font-bold text-gray-700"><?php echo htmlspecialchars($booking['service_name']); ?></span>
                        </div>
                        <div class="flex justify-between text-xs">
                            <span class="text-gray-400">Schedule</span>
                            <span class="font-bold text-gray-700"><?php echo date('M d, Y', strtotime($booking['booking_date'])); ?></span>
                        </div>
                    </div>

                    <div class="flex items-center gap-2 text-sm text-blue-600 font-bold mb-6">
                        <i data-lucide="phone" class="w-4 h-4"></i>
                        <a href="tel:<?php echo $booking['user_phone']; ?>"><?php echo htmlspecialchars($booking['user_phone']); ?></a>
                    </div>

                    <!-- Actions Based on Status -->
                    <div class="mt-auto pt-4 border-t border-gray-50">
                        <?php if ($booking['status'] == 'Pending'): ?>
                            <button onclick="updateStatus(<?php echo $booking['id']; ?>, 'Received')" class="w-full bg-primary text-white py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-blue-100 hover:bg-blue-600 transition">Receive Order</button>
                        <?php elseif ($booking['status'] == 'Received'): ?>
                            <button onclick="updateStatus(<?php echo $booking['id']; ?>, 'Completed')" class="w-full bg-green-600 text-white py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-green-100 hover:bg-green-700 transition">Complete Transaction</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </main>

    <script>
        lucide.createIcons();

        async function updateStatus(id, status) {
            const formData = new FormData();
            formData.append('booking_id', id);
            formData.append('status', status);

            const res = await fetch('../admin/api_update_status.php', {
                method: 'POST',
                body: formData
            });

            const result = await res.json();
            if (result.success) {
                location.reload();
            } else {
                alert('Error: ' + result.message);
            }
        }
    </script>
</body>
</html>
