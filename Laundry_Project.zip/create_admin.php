<?php
require_once 'config/db.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $secret_key = $_POST['secret_key'];
    
    // Default values for admin
    $phone = "0000000000";
    $address = "Admin HQ";
    $city = "Admin City";
    $zip = "0000";

    // Simple security check to prevent unauthorized creation
    // In a real app, this should be behind a login or a more secure mechanism
    $ADMIN_CREATION_KEY = "WashaholicSecretKey2025"; 

    if (empty($name) || empty($email) || empty($password)) {
        $error = "Please fill in all required fields.";
    } elseif ($secret_key !== $ADMIN_CREATION_KEY) {
        $error = "Invalid Secret Key. You are not authorized to create admins.";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $error = "Name must only contain letters and spaces.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match("/@gmail\.com$/", $email)) {
        $error = "Only @gmail.com email addresses are accepted.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Email already registered.";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $sql = "INSERT INTO users (name, email, phone, address, city, zip, password, role) VALUES (?, ?, ?, ?, ?, ?, ?, 'admin')";
            $stmt = $pdo->prepare($sql);
            
            if ($stmt->execute([$name, $email, $phone, $address, $city, $zip, $hashed_password])) {
                $success = "Success! Admin account created for <b>$email</b>.";
            } else {
                $error = "Database error. Could not create user.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-800 text-gray-100 min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full bg-gray-700 p-8 rounded-lg shadow-lg">
        <h2 class="text-2xl font-bold mb-6 text-center text-blue-400">Create New Admin</h2>
        
        <?php if($error): ?>
            <div class="bg-red-500 text-white p-3 rounded mb-4 text-sm font-bold">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if($success): ?>
            <div class="bg-green-500 text-white p-3 rounded mb-4 text-sm font-bold">
                <?php echo $success; ?> <a href="login.php" class="underline">Login Now</a>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium">Secret Key</label>
                <input type="password" name="secret_key" required class="w-full px-3 py-2 bg-gray-600 rounded border border-gray-500 focus:outline-none focus:border-blue-400" placeholder="Enter secure key to authorize">
            </div>

            <div>
                <label class="block text-sm font-medium">Full Name</label>
                <input type="text" name="name" required pattern="[a-zA-Z\s]+" title="Letters only" class="w-full px-3 py-2 bg-gray-600 rounded border border-gray-500 focus:outline-none focus:border-blue-400">
            </div>

            <div>
                <label class="block text-sm font-medium">Email</label>
                <input type="email" name="email" required pattern=".*@gmail\.com$" title="Only @gmail.com addresses allowed" class="w-full px-3 py-2 bg-gray-600 rounded border border-gray-500 focus:outline-none focus:border-blue-400">
            </div>

            <div>
                <label class="block text-sm font-medium">Password</label>
                <input type="password" name="password" required class="w-full px-3 py-2 bg-gray-600 rounded border border-gray-500 focus:outline-none focus:border-blue-400">
            </div>

            <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition">
                Create Admin
            </button>
            
            <p class="text-xs text-start text-gray-400 mt-2">Secret Key: WashaholicSecretKey2025</p>
        </form>
    </div>
</body>
</html>
