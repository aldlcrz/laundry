<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM users WHERE role = 'admin' ORDER BY name ASC");
$admins = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Manage Admins - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { theme: { extend: { fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'] }, colors: { primary: '#3b82f6' } } } }
    </script>
</head>
<body class="bg-[#f8fafc] font-sans antialiased text-gray-800">
    <?php include 'includes/sidebar.php'; ?>

    <div class="ml-64 p-8 min-h-screen">
        <div class="flex justify-between items-end mb-8">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Administrator Panel</h1>
                <p class="text-gray-500 text-sm mt-1">Manage system administrators.</p>
            </div>
            <a href="../create_admin.php" class="bg-primary text-white px-6 py-2.5 rounded-xl font-bold hover:bg-blue-600 transition shadow-lg shadow-blue-100 flex items-center gap-2">
                <i data-lucide="plus" class="w-5 h-5"></i> Create Admin
            </a>
        </div>

        <div class="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden text-nowrap">
            <table class="w-full text-left">
                <thead class="bg-gray-50/50">
                    <tr>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Administrator</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Email</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Control Level</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($admins as $a): ?>
                    <tr class="hover:bg-gray-50/50 transition-colors">
                        <td class="px-6 py-5">
                            <div class="flex items-center gap-3">
                                <div class="h-8 w-8 bg-blue-100 text-primary font-bold rounded-lg flex items-center justify-center text-xs">
                                    <?php echo strtoupper(substr($a['name'], 0, 1)); ?>
                                </div>
                                <span class="font-bold text-gray-900 text-sm"><?php echo htmlspecialchars($a['name']); ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-5 text-sm text-gray-500"><?php echo htmlspecialchars($a['email']); ?></td>
                        <td class="px-6 py-5">
                            <span class="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-[10px] font-bold border border-blue-200 uppercase">Super Admin</span>
                        </td>
                        <td class="px-6 py-5">
                             <?php if ($a['id'] != $_SESSION['user_id']): ?>
                                <button onclick="deleteUser(<?php echo $a['id']; ?>)" class="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition">
                                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                                </button>
                             <?php else: ?>
                                <span class="text-xs text-gray-400 font-medium italic">Current Account</span>
                             <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        lucide.createIcons();
        async function deleteUser(userId) {
            if (!confirm('Are you sure you want to remove this admin?')) return;
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('user_id', userId);
            const res = await fetch('api_users.php', { method: 'POST', body: formData });
            if ((await res.json()).success) location.reload();
        }
    </script>
</body>
</html>
