<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Fetch stats
$totalBookings = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$totalCustomers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$totalSales = $pdo->query("SELECT SUM(total_amount) FROM bookings WHERE status NOT IN ('Cancelled')")->fetchColumn() ?? 0;
$profit = $totalSales * 0.35; // Mock profit calculation (35%)

// 1. Peak Service Hours (Last 30 Days)
$peakHoursStmt = $pdo->query("
    SELECT HOUR(created_at) as hr, COUNT(*) as count 
    FROM bookings 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY hr ORDER BY hr ASC
");
$peakHoursData = $peakHoursStmt->fetchAll(PDO::FETCH_KEY_PAIR);
$allHours = array_fill(0, 24, 0);
foreach ($peakHoursData as $hr => $count) $allHours[$hr] = $count;

// 2. Daily Sales Trends (Last 14 Days)
$salesTrendStmt = $pdo->query("
    SELECT DATE_FORMAT(created_at, '%b %d') as dt, SUM(total_amount) as total 
    FROM bookings 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
    GROUP BY DATE(created_at) ORDER BY DATE(created_at) ASC
");
$salesTrendData = $salesTrendStmt->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'] },
                    colors: { primary: '#3b82f6', secondary: '#1e40af', bgLight: '#f8fafc' }
                }
            }
        }
    </script>
    <style>
        body { background-color: #f8fafc; }
    </style>
</head>
<body class="antialiased text-gray-800">

    <?php include 'includes/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="ml-64 p-8 min-h-screen">
        <!-- Header -->
        <div class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 tracking-tight">System Overview</h1>
                <p class="text-gray-500 text-sm mt-1">Welcome back, Admin. Here's what's happening today.</p>
            </div>
            <div class="flex items-center gap-4">
                <div class="h-10 w-10 bg-white border border-gray-100 rounded-full flex items-center justify-center text-gray-400 cursor-pointer hover:bg-gray-50 shadow-sm relative">
                    <i data-lucide="bell" class="w-5 h-5"></i>
                    <span class="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
                </div>
                <div class="h-10 w-10 bg-blue-100 text-primary font-bold rounded-full flex items-center justify-center shadow-sm">
                    <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <!-- Profit Card -->
            <div class="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex justify-between items-start mb-4">
                    <div class="p-3 bg-blue-50 text-blue-600 rounded-xl">
                        <i data-lucide="trending-up" class="w-6 h-6"></i>
                    </div>
                    <span class="text-[11px] font-bold text-green-500 bg-green-50 px-2 py-1 rounded-full">+12.5%</span>
                </div>
                <p class="text-sm font-medium text-gray-500">Estimated Profit</p>
                <h3 class="text-2xl font-bold text-gray-900 mt-1">₱<?php echo number_format($profit, 2); ?></h3>
            </div>

            <!-- Sale Card -->
            <div class="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex justify-between items-start mb-4">
                    <div class="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
                        <i data-lucide="banknote" class="w-6 h-6"></i>
                    </div>
                    <span class="text-[11px] font-bold text-green-500 bg-green-50 px-2 py-1 rounded-full">+8.2%</span>
                </div>
                <p class="text-sm font-medium text-gray-500">Total Sales</p>
                <h3 class="text-2xl font-bold text-gray-900 mt-1">₱<?php echo number_format($totalSales, 2); ?></h3>
            </div>

            <!-- Total Bookings -->
            <div class="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex justify-between items-start mb-4">
                    <div class="p-3 bg-cyan-50 text-cyan-600 rounded-xl">
                        <i data-lucide="calendar-check" class="w-6 h-6"></i>
                    </div>
                    <span class="text-[11px] font-bold text-blue-500 bg-blue-50 px-2 py-1 rounded-full">+24 today</span>
                </div>
                <p class="text-sm font-medium text-gray-500">Total Bookings</p>
                <h3 class="text-2xl font-bold text-gray-900 mt-1"><?php echo $totalBookings; ?></h3>
            </div>

            <!-- Total Customers -->
            <div class="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex justify-between items-start mb-4">
                    <div class="p-3 bg-violet-50 text-violet-600 rounded-xl">
                        <i data-lucide="users" class="w-6 h-6"></i>
                    </div>
                    <span class="text-[11px] font-bold text-violet-500 bg-violet-50 px-2 py-1 rounded-full">Active</span>
                </div>
                <p class="text-sm font-medium text-gray-500">Total Customers</p>
                <h3 class="text-2xl font-bold text-gray-900 mt-1"><?php echo $totalCustomers; ?></h3>
            </div>
        </div>

        <!-- Charts Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Bookings Chart -->
            <div class="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                <div class="flex justify-between items-center mb-8">
                    <h3 class="text-lg font-bold text-gray-900">Daily Sales Trends</h3>
                    <select class="bg-gray-50 border-none text-xs text-gray-500 rounded-lg px-3 py-2 outline-none">
                        <option>Last 6 Months</option>
                    </select>
                </div>
                <canvas id="bookingsChart" height="240"></canvas>
            </div>

            <!-- Revenue Chart -->
            <div class="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                <div class="flex justify-between items-center mb-8">
                    <h3 class="text-lg font-bold text-gray-900">Peak Service Hours</h3>
                    <select class="bg-gray-50 border-none text-xs text-gray-500 rounded-lg px-3 py-2 outline-none">
                        <option>Last 6 Months</option>
                    </select>
                </div>
                <canvas id="revenueChart" height="240"></canvas>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();

        // Chart 1: Daily Sales Trends
        const ctxSales = document.getElementById('bookingsChart').getContext('2d');
        new Chart(ctxSales, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_keys($salesTrendData)); ?>,
                datasets: [{
                    label: 'Daily Sales (₱)',
                    data: <?php echo json_encode(array_values($salesTrendData)); ?>,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.05)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointBackgroundColor: '#3b82f6'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { 
                    y: { beginAtZero: true, grid: { color: '#f1f5f9' }, border: { display: false } },
                    x: { grid: { display: false }, border: { display: false } }
                }
            }
        });

        // Chart 2: Peak Service Hours
        const ctxPeak = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctxPeak, {
            type: 'bar',
            data: {
                labels: ['12AM','1AM','2AM','3AM','4AM','5AM','6AM','7AM','8AM','9AM','10AM','11AM','12PM','1PM','2PM','3PM','4PM','5PM','6PM','7PM','8PM','9PM','10PM','11PM'],
                datasets: [{
                    label: 'Bookings',
                    data: <?php echo json_encode(array_values($allHours)); ?>,
                    backgroundColor: '#8b5cf6',
                    borderRadius: 6,
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { 
                    y: { beginAtZero: true, grid: { color: '#f1f5f9' }, border: { display: false } },
                    x: { grid: { display: false }, border: { display: false } }
                }
            }
        });
    </script>
</body>
</html>
