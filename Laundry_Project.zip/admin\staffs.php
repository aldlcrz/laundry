<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM users WHERE role = 'staff' ORDER BY name ASC");
$staffs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">    <title>Manage Staff - Laundry Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { theme: { extend: { fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'] }, colors: { primary: '#3b82f6' } } } }
    </script>
</head>
<body class="bg-[#f8fafc] font-sans antialiased text-gray-800">
    <?php include 'includes/sidebar.php'; ?>

    <div class="ml-64 p-8 min-h-screen">
        <div class="flex justify-between items-end mb-8">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Staff Management</h1>
                <p class="text-gray-500 text-sm mt-1">Manage delivery and laundry personnel.</p>
            </div>
            <a href="create_staff.php" class="bg-primary text-white px-6 py-2.5 rounded-xl font-bold hover:bg-blue-600 transition shadow-lg shadow-blue-100 flex items-center gap-2">
                <i data-lucide="plus" class="w-5 h-5"></i> Add Member
            </a>
        </div>

        <div class="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden text-nowrap">
            <table class="w-full text-left">
                <thead class="bg-gray-50/50">
                    <tr>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Name</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Email</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Phone</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                        <th class="px-6 py-4 text-[11px] font-bold text-gray-400 uppercase tracking-widest">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php if (empty($staffs)): ?>
                    <tr><td colspan="5" class="px-6 py-12 text-center text-gray-400 italic">No staff members found.</td></tr>
                    <?php endif; ?>

                    <?php foreach ($staffs as $s): ?>
                    <tr class="hover:bg-gray-50/50 transition-colors">
                        <td class="px-6 py-5 font-bold text-gray-900 text-sm"><?php echo htmlspecialchars($s['name']); ?></td>
                        <td class="px-6 py-5 text-sm text-gray-500"><?php echo htmlspecialchars($s['email']); ?></td>
                        <td class="px-6 py-5 text-sm text-gray-500"><?php echo htmlspecialchars($s['phone']); ?></td>
                        <td class="px-6 py-5">
                            <select onchange="updateRole(<?php echo $s['id']; ?>, this.value)" class="bg-green-50 text-green-700 text-[10px] font-bold px-2 py-1 rounded-full outline-none border-none cursor-pointer">
                                <option value="staff" selected>Active Staff</option>
                                <option value="admin">Promote Admin</option>
                                <option value="customer">Demote to User</option>
                            </select>
                        </td>
                        <td class="px-6 py-5">
                            <button onclick="deleteUser(<?php echo $s['id']; ?>)" class="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition">
                                <i data-lucide="trash-2" class="w-4 h-4"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        lucide.createIcons();
        async function updateRole(userId, role) {
            const formData = new FormData();
            formData.append('action', 'toggle_role');
            formData.append('user_id', userId);
            formData.append('role', role);
            const res = await fetch('api_users.php', { method: 'POST', body: formData });
            if ((await res.json()).success) location.reload();
        }
        async function deleteUser(userId) {
            if (!confirm('Are you sure?')) return;
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('user_id', userId);
            const res = await fetch('api_users.php', { method: 'POST', body: formData });
            if ((await res.json()).success) location.reload();
        }
    </script>
</body>
</html>
