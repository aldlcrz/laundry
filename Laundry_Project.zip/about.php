<?php
include 'includes/header.php';
?>

<div class="bg-white">
  <!-- Hero Section -->
  <div class="relative bg-primary">
    <div class="absolute inset-0">
      <img class="w-full h-full object-cover mix-blend-multiply filter brightness-50" src="https://images.unsplash.com/photo-1517677208171-0bc5e7e32602?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" alt="Laundry Team">
      <div class="absolute inset-0 bg-secondary mix-blend-multiply opacity-60"></div>
    </div>
    <div class="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8 text-center">
      <h1 class="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">About Washaholic</h1>
      <p class="mt-6 text-xl text-blue-100 max-w-3xl mx-auto">We are redefining the laundry experience with premium care, speed, and convenience.</p>
    </div>
  </div>

  <!-- Our Story -->
  <div class="py-16 overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
        <div>
            <h1 class="text-4xl font-extrabold text-gray-900 tracking-tight sm:text-5xl">
                About Laundry Project
            </h1>
            <p class="mt-4 text-xl text-gray-500">
                Revolutionizing laundry care with premium, app-first service.
            </p>
          <p class="mt-4 text-lg text-gray-500">
            Founded in 2024, Laundry Project started with a simple mission: to give people back their time. We understood that in today's fast-paced world, doing laundry is a chore that takes away from precious moments with family and friends. We treat every garment with the utmost care, ensuring you always look your best.
          </p>
        </div>
        <div class="mt-10 lg:mt-0">
            <img class="rounded-lg shadow-xl" src="https://images.unsplash.com/photo-1521656693072-a8333fd29825?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" alt="Laundromat Interior">
        </div>
      </div>
    </div>
  </div>

  <!-- Why Choose Us -->
  <div class="bg-gray-50 py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="text-center">
        <h2 class="text-base text-primary font-semibold tracking-wide uppercase">Why Choose Us</h2>
        <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
          The Washaholic Standard
        </p>
      </div>

      <div class="mt-10">
        <div class="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
            <div class="p-6 bg-white rounded-lg shadow-md text-center">
                <div class="mx-auto h-12 w-12 text-primary text-4xl mb-4">
                    <i class="fas fa-leaf"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900">Eco-Friendly</h3>
                <p class="mt-2 text-base text-gray-500">We use biodegradable detergents and energy-efficient machines to protect the planet.</p>
            </div>
            
            <div class="p-6 bg-white rounded-lg shadow-md text-center">
                <div class="mx-auto h-12 w-12 text-primary text-4xl mb-4">
                    <i class="fas fa-truck"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900">Doorstep Delivery</h3>
                <p class="mt-2 text-base text-gray-500">We pick up and deliver straight to your door, saving you the trip.</p>
            </div>
            
            <div class="p-6 bg-white rounded-lg shadow-md text-center">
                <div class="mx-auto h-12 w-12 text-primary text-4xl mb-4">
                    <i class="fas fa-gem"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900">Premium Care</h3>
                <p class="mt-2 text-base text-gray-500">From silk to denim, we handle every fabric with specialized cleaning techniques.</p>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
