-- LAUNDRY PROJECT - FINAL DATABASE SCHEMA
-- Includes Google OAuth support and verified Admin credentials.
-- Instructions: Import this into your phpMyAdmin.

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- CLEAN UP
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `services`;
DROP TABLE IF EXISTS `users`;

-- USERS TABLE (With Google Support)
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','customer','staff') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `google_id` (`google_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SERVICES TABLE
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `base_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- BOOKINGS TABLE
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `address` text NOT NULL,
  `schedule_date` date NOT NULL,
  `status` enum('Pending','Received','Completed','Cancelled') DEFAULT 'Pending',
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT 'Cash on Pickup',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- NOTIFICATIONS TABLE
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `type` enum('status_update','general') DEFAULT 'status_update',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SEED DATA
-- Password is 'admin123'
INSERT INTO `users` (`name`, `email`, `phone`, `address`, `password`, `role`) VALUES
('Admin User', 'admin@laundryproject.com', '1234567890', 'Main Office', '$2y$10$8B07oB9R3K/fPgh5K0P0re.i.9S2pGlHicmclJvI3v5qE7YyT2t.W', 'admin');

-- Default Staff (Password: admin123)
INSERT INTO `users` (`name`, `email`, `phone`, `address`, `password`, `role`) VALUES
('Main Staff', 'staff@gmail.com', '0987654321', 'Staff Base', '$2y$10$8B07oB9R3K/fPgh5K0P0re.i.9S2pGlHicmclJvI3v5qE7YyT2t.W', 'staff');

-- Services
INSERT INTO `services` (`service_name`, `description`, `base_price`) VALUES
('Wash & Fold', 'Professional washing and drying, folded neatly.', 150.00),
('Wash & Iron', 'Professional washing, drying, and steam ironing.', 250.00),
('Dry Cleaning', 'Special care for delicate fabrics.', 500.00),
('Comforter/Blanket', 'Deep cleaning for large bedding items.', 350.00);

COMMIT;
