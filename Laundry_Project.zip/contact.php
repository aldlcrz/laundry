<?php
include 'includes/header.php';
?>

<div class="bg-gray-50 py-16 px-4 sm:px-6 lg:px-8">
  <div class="max-w-7xl mx-auto">
    <div class="text-center">
      <h2 class="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl">
        Contact Us
      </h2>
      <p class="mt-4 text-lg leading-6 text-gray-500">
        Have questions? We'rere here to help. Reach out to us via phone, email, or visit our store.
      </p>
    </div>
    
    <div class="mt-16 bg-white rounded-lg shadow-xl overflow-hidden lg:grid lg:grid-cols-2 lg:gap-4">
      <!-- Contact Info -->
      <div class="pt-10 pb-12 px-6 sm:pt-16 sm:px-16 lg:py-16 lg:pr-0 xl:py-20 xl:px-20 bg-primary">
        <div class="lg:self-center">
          <h2 class="text-3xl font-extrabold text-white sm:text-4xl">
            <span class="block">Get in touch</span>
          </h2>
          <p class="mt-4 text-lg leading-6 text-blue-100">
            Our support team is available Monday to Saturday, 8am to 8pm.
          </p>
          <dl class="mt-8 space-y-6">
            <div class="flex">
               <div class="flex-shrink-0">
                <i class="fas fa-phone text-blue-200"></i>
               </div>
               <div class="ml-3 text-base text-blue-50">
                 <p>+1 (555) 123-4567</p>
                 <p class="mt-1">Mon-Sat 8am to 8pm</p>
               </div>
            </div>
            <div class="flex">
               <div class="flex-shrink-0">
                <i class="fas fa-envelope text-blue-200"></i>
               </div>
               <div class="ml-3 text-base text-blue-50">
                 <p class="mt-1 text-gray-400">support@laundryproject.com</p>
               </div>
            </div>
            <div class="flex">
               <div class="flex-shrink-0">
                <i class="fas fa-map-marker-alt text-blue-200"></i>
               </div>
               <div class="ml-3 text-base text-blue-50">
                 <p>123 Clean Street</p>
                 <p class="mt-1">Laundry City, ST 12345</p>
               </div>
            </div>
          </dl>
          
          <!-- Socials -->
          <div class="mt-12 flex space-x-6">
              <a href="#" class="text-blue-200 hover:text-white"><i class="fab fa-facebook fa-lg"></i></a>
              <a href="#" class="text-blue-200 hover:text-white"><i class="fab fa-instagram fa-lg"></i></a>
              <a href="#" class="text-blue-200 hover:text-white"><i class="fab fa-twitter fa-lg"></i></a>
          </div>
        </div>
      </div>

      <!-- Contact Form -->
      <div class="py-10 px-6 sm:px-10 lg:col-span-1">
        <h1 class="text-3xl font-extrabold text-gray-900">Contact Laundry Project</h1>
        <form action="#" method="POST" class="mt-6 grid grid-cols-1 gap-y-6">
          <div>
            <label for="full-name" class="block text-sm font-medium text-gray-700">Full name</label>
            <div class="mt-1">
              <input type="text" name="full-name" id="full-name" autocomplete="name" class="py-3 px-4 block w-full shadow-sm focus:ring-primary focus:border-primary border-gray-300 rounded-md">
            </div>
          </div>
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
            <div class="mt-1">
              <input id="email" name="email" type="email" autocomplete="email" class="py-3 px-4 block w-full shadow-sm focus:ring-primary focus:border-primary border-gray-300 rounded-md">
            </div>
          </div>
          <div>
            <label for="message" class="block text-sm font-medium text-gray-700">Message</label>
            <div class="mt-1">
              <textarea id="message" name="message" rows="4" class="py-3 px-4 block w-full shadow-sm focus:ring-primary focus:border-primary border border-gray-300 rounded-md"></textarea>
            </div>
          </div>
          <div>
            <button type="submit" class="w-full inline-flex justify-center py-3 px-6 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-primary hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
              SendMessage
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
