    </div> <!-- End flex-grow -->
    
    <footer class="bg-gray-900 text-white pt-10 pb-6 mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div class="col-span-1 md:col-span-2">
                    <span class="ml-2 text-xl font-bold text-white tracking-tight">Laundry Project</span>
                    <p class="mt-4 text-gray-400 text-sm">Laundry Project provides the highest quality laundry and dry cleaning services with a focus on convenience and customer satisfaction.</p>
                </div>
                <div>
                    <h4 class="text-lg font-semibold mb-4 text-gray-200">Quick Links</h4>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-400 hover:text-white transition">Home</a></li>
                        <li><a href="index.php#services" class="text-gray-400 hover:text-white transition">Services</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition">Privacy Policy</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-lg font-semibold mb-4 text-gray-200">Contact Us</h4>
                    <ul class="space-y-2 text-gray-400">
                        <li><i class="fas fa-envelope mr-2"></i> info@laundryproject.com</li>
                        <li><i class="fas fa-phone mr-2"></i> +1 234 567 8900</li>
                        <li><i class="fas fa-map-marker-alt mr-2"></i> 123 Laundry St, Clean City</li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
              <p class="text-gray-400 text-sm">&copy; <?php echo date('Y'); ?> Laundry Project. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
