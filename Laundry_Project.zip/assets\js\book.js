document.addEventListener('DOMContentLoaded', () => {
    const calendarDays = document.getElementById('calendarDays');
    const currentMonthYear = document.getElementById('currentMonthYear');
    const prevMonthBtn = document.getElementById('prevMonth');
    const nextMonthBtn = document.getElementById('nextMonth');
    const bookingModal = document.getElementById('bookingModal');
    const selectedDateText = document.getElementById('selectedDateText');
    const selectedDateInput = document.getElementById('selectedDate');
    const totalDisplay = document.getElementById('totalDisplay');
    const totalInput = document.getElementById('totalInput');
    
    let currentDate = new Date();
    
    function renderCalendar() {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        
        currentMonthYear.innerText = new Date(year, month).toLocaleString('default', { month: 'long', year: 'numeric' });
        
        // First day of the month
        const firstDay = new Date(year, month, 1).getDay();
        // Days in month
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        calendarDays.innerHTML = '';
        
        // Empty slots for previous month
        for(let i = 0; i < firstDay; i++) {
            const div = document.createElement('div');
            calendarDays.appendChild(div);
        }
        
        // Days
        for(let i = 1; i <= daysInMonth; i++) {
            const div = document.createElement('div');
            div.innerText = i;
            div.className = 'bg-gray-50 border border-gray-200 rounded-lg h-24 flex items-start justify-end p-2 cursor-pointer hover:bg-blue-50 transition';
            
            // Check if past date
            const checkDate = new Date(year, month, i);
            const today = new Date();
            today.setHours(0,0,0,0);
            
            if (checkDate < today) {
                div.classList.add('opacity-50', 'cursor-not-allowed', 'bg-gray-100');
                div.classList.remove('hover:bg-blue-50', 'cursor-pointer');
            } else {
                div.onclick = () => openModal(year, month, i);
            }
            
            calendarDays.appendChild(div);
        }
    }
    
    prevMonthBtn.onclick = () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    };
    
    nextMonthBtn.onclick = () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    };
    
    window.openModal = (year, month, day) => {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        selectedDateText.innerText = new Date(year, month, day).toLocaleDateString();
        selectedDateInput.value = dateStr;
        bookingModal.classList.remove('hidden');
        calculateTotal();
    };
    
    window.closeModal = () => {
        bookingModal.classList.add('hidden');
        document.getElementById('bookingForm').reset();
        totalDisplay.innerText = '₱0.00';
    };
    
    window.calculateTotal = () => {
        let total = 0;
        
        // Service Price
        const selectedService = document.querySelector('input[name="service_id"]:checked');
        if (selectedService) {
            total += parseFloat(selectedService.dataset.price);
        }
        
        // Add-ons
        const addons = document.querySelectorAll('input[name="addons[]"]:checked');
        addons.forEach(addon => {
            total += parseFloat(addon.dataset.price);
        });
        
        totalDisplay.innerText = '₱' + total.toFixed(2);
        totalInput.value = total;
    };
    
    window.submitBooking = async () => {
        const form = document.getElementById('bookingForm');
        const formData = new FormData(form);
        
        // Validate
        if (!formData.get('service_id')) {
            alert('Please select a service');
            return;
        }
        
        try {
            const response = await fetch('api/process_booking.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Booking Confirmed!');
                closeModal();
                // Optionally refresh or show indication on calendar
            } else {
                alert(result.message || 'Booking failed');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        }
    };
    
    renderCalendar();
});
