<?php
require_once '../config/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $serviceId = $_POST['service_id'];
    $bookingDate = $_POST['date']; // YYYY-MM-DD
    $totalAmount = $_POST['total_amount'];
    $paymentMethod = $_POST['payment_method'];
    $addons = isset($_POST['addons']) ? $_POST['addons'] : []; // Array of addon names

    try {
        $pdo->beginTransaction();

        // Validate Service
        $stmt = $pdo->prepare("SELECT base_price FROM services WHERE id = ?");
        $stmt->execute([$serviceId]);
        $service = $stmt->fetch();
        if (!$service) {
            throw new Exception("Invalid Service");
        }

        // Insert Booking
        $sql = "INSERT INTO bookings (user_id, service_id, booking_date, total_amount, payment_method, status) VALUES (?, ?, ?, ?, ?, 'Pending')";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId, $serviceId, $bookingDate, $totalAmount, $paymentMethod]);
        $bookingId = $pdo->lastInsertId();

        // Insert Add-ons
        // Defined addon prices for backend validation (simplified for now)
        $addonPrices = [
            'Extra Wash' => 150.00,
            'Extra Dry' => 120.00,
            'Extra Rinse' => 100.00
        ];

        if (!empty($addons)) {
            $addonSql = "INSERT INTO additional_services (booking_id, addon_name, price) VALUES (?, ?, ?)";
            $addonStmt = $pdo->prepare($addonSql);
            
            foreach ($addons as $addonName) {
                if (array_key_exists($addonName, $addonPrices)) {
                    $addonStmt->execute([$bookingId, $addonName, $addonPrices[$addonName]]);
                }
            }
        }

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Booking confirmed!']);

    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Booking failed: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid Request']);
}
?>
